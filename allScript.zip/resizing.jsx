// #target illustrator
(function () {
  /* ========= 사용자 설정 ========= */
  var NAME_PREFIX = "이미지_";   // 이 접두어로 시작하는 PlacedItem 들만 대상
  var UNIT_MM = true;            // 입력을 mm로 받을지(=true) pt로 받을지(=false)
  var FORCE_CREATE_CLIP = true;  // 기존 클리핑 없으면 자동 생성

  /* ========= 유틸 ========= */
  function mm2pt(mm) { return mm * 2.834645669; } // ES3용 고정 상수

  function parseDim(promptTitle) {
    var w = prompt(promptTitle + " 가로 크기를 " + (UNIT_MM ? "mm" : "pt") + " 단위로 입력", "100");
    if (w === null) return null;
    var h = prompt(promptTitle + " 세로 크기를 " + (UNIT_MM ? "mm" : "pt") + " 단위로 입력", "150");
    if (h === null) return null;
    w = parseFloat(w); h = parseFloat(h);
    if (!(w > 0 && h > 0)) { alert("유효하지 않은 크기입니다."); return null; }
    if (UNIT_MM) { w = mm2pt(w); h = mm2pt(h); }
    return {W:w, H:h};
  }

  // cover 스케일: 비율 유지, 박스를 꽉 채우기(넘치면 잘림)
  function coverScale(pic, boxW, boxH) {
    var iw = pic.width, ih = pic.height;
    var sx = boxW / iw, sy = boxH / ih;
    return Math.max(sx, sy);
  }

  // pic을 boxRect(geom bounds 기반)의 중앙에 배치
  function centerIn(pic, boxRect) {
    var L = boxRect[0], T = boxRect[1], R = boxRect[2], B = boxRect[3];
    var bw = R - L, bh = T - B;
    var pw = pic.width, ph = pic.height;
    var posX = L + (bw - pw) / 2;
    var posY = T - (bh - ph) / 2;
    pic.position = [posX, posY];
  }

  // pic과 같은 레이어에 클리핑 사각형(투명) + 그룹 생성 (없으면)
  // 반환: { group, rect, rectBounds }
  function ensureClipGroup(pic, boxW, boxH) {
    // 이미 부모가 그룹이고 그 그룹이 clipped=true 이면 그 그룹을 사용
    var parent = pic.parent;
    if (parent.typename === "GroupItem" && parent.clipped) {
      var first = parent.pageItems.length > 0 ? parent.pageItems[0] : null;
      if (first && first.typename === "PathItem") {
        return { group: parent, rect: first, rectBounds: first.geometricBounds };
      }
    }

    if (!FORCE_CREATE_CLIP) return null;

    // 현재 그림의 중심을 기준으로 클립박스 생성
    var gb = pic.geometricBounds; // [L,T,R,B]
    var cx = (gb[0] + gb[2]) / 2;
    var cy = (gb[1] + gb[3]) / 2;
    var L = cx - boxW/2, T = cy + boxH/2;

    var lay = pic.layer;
    var rect = lay.pathItems.rectangle(T, L, boxW, boxH);
    rect.stroked = false; rect.filled = false;

    var grp = lay.groupItems.add();
    rect.move(grp, ElementPlacement.PLACEATBEGINNING);
    pic.move(grp, ElementPlacement.PLACEATEND);
    grp.clipped = true;

    return { group: grp, rect: rect, rectBounds: rect.geometricBounds };
  }

  // 한 PlacedItem을 boxW x boxH 중앙 cover 배치 + 클리핑 보장
  function fitOne(pic, boxW, boxH) {
    app.redraw();

    var clipInfo = ensureClipGroup(pic, boxW, boxH);
    if (!clipInfo) {
      // 클립이 없고 생성도 안 하기로 했다면, 박스 기준은 현재 위치에서 만든 가상 박스
      var gb = pic.geometricBounds;
      var L = gb[0], T = gb[1];
      var rectBounds = [L, T, L + boxW, T - boxH];
      var s = coverScale(pic, boxW, boxH);
      pic.resize(s*100, s*100);
      app.redraw();
      centerIn(pic, rectBounds);
      return;
    }

    var rectBounds = clipInfo.rectBounds;
    var s2 = coverScale(pic, boxW, boxH);
    pic.resize(s2*100, s2*100);
    app.redraw();
    centerIn(pic, rectBounds);
  }

  // 이름이 NAME_PREFIX 로 시작하는 PlacedItem 목록 수집(현재 문서 전체)
  function collectTargets(doc) {
    var arr = [];
    var pi = doc.placedItems;
    for (var i = 0; i < pi.length; i++) {
      var p = pi[i];
      if (p.name && p.name.indexOf(NAME_PREFIX) === 0) arr.push(p);
    }
    return arr;
  }

  /* ========= 본문 ========= */
  if (app.documents.length === 0) { alert("문서가 없습니다."); return; }
  var doc = app.activeDocument;
  if (doc.dataSets.length === 0) { alert("데이터셋이 없습니다."); return; }

  var dim = parseDim("리사이즈 기준 박스");
  if (!dim) return;

  // 우선 현재(표시 중인) 데이터셋에서 대상 수집
  var targets = collectTargets(doc);
  if (targets.length === 0) {
    alert("대상 이미지(이름이 '" + NAME_PREFIX + "…')가 없습니다.");
    return;
  }

  // 대상마다 클립 그룹 1회 보장 + 현재 데이터셋에 맞춰 1회 배치
  for (var t = 0; t < targets.length; t++) {
    fitOne(targets[t], dim.W, dim.H);
  }

  // 모든 데이터셋을 돌면서 동일 처리 (각 데이터셋의 링크 이미지 크기 반영)
  var DS = doc.dataSets;
  for (var di = 0; di < DS.length; di++) {
    DS[di].display();
    app.redraw();

    // 같은 이름의 PlacedItem 들을 다시 수집(데이터셋 전환으로 링크/크기 변함)
    targets = collectTargets(doc);
    for (t = 0; t < targets.length; t++) {
      fitOne(targets[t], dim.W, dim.H);
    }
  }

  alert("✅ 모든 데이터셋에 대해 '" + NAME_PREFIX + "…' 이미지들을\n" +
        (UNIT_MM ? "(mm 입력)" : "(pt 입력)") + 
        " " + (UNIT_MM ? ( (dim.W/2.834645669).toFixed(2) + " x " + (dim.H/2.834645669).toFixed(2) + " mm") 
                      : ( dim.W.toFixed(2) + " x " + dim.H.toFixed(2) + " pt")) +
        " 박스에 맞춰 '비율 유지(cover) + 중앙정렬 + 클리핑'으로 리사이즈 완료.");
})();
